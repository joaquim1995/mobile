package com.nodomain.freeyourgadget.gadgetbridge.adapter;

import android.content.Context;
import android.widget.Toast;

import com.nodomain.freeyourgadget.gadgetbridge.GBApplication;
import com.nodomain.freeyourgadget.gadgetbridge.database.DBHandler;
import com.nodomain.freeyourgadget.gadgetbridge.database.DBHelper;
import com.nodomain.freeyourgadget.gadgetbridge.entities.BaseActivitySummary;
import com.nodomain.freeyourgadget.gadgetbridge.entities.BaseActivitySummaryDao;
import com.nodomain.freeyourgadget.gadgetbridge.entities.Device;
import com.nodomain.freeyourgadget.gadgetbridge.impl.GBDevice;
import com.nodomain.freeyourgadget.gadgetbridge.model.ActivityKind;
import com.nodomain.freeyourgadget.gadgetbridge.util.DateTimeUtils;
import com.nodomain.freeyourgadget.gadgetbridge.util.GB;

import java.util.Date;
import java.util.List;

import de.greenrobot.dao.query.QueryBuilder;

public class ActivitySummariesAdapter extends AbstractItemAdapter<BaseActivitySummary> {
    private final GBDevice device;

    public ActivitySummariesAdapter(Context context, GBDevice device) {
        super(context);
        this.device = device;
        loadItems();
    }

    @Override
    public void loadItems() {
        try (DBHandler handler = GBApplication.acquireDB()) {
            BaseActivitySummaryDao summaryDao = handler.getDaoSession().getBaseActivitySummaryDao();
            Device dbDevice = DBHelper.findDevice(device, handler.getDaoSession());

            QueryBuilder<BaseActivitySummary> qb = summaryDao.queryBuilder();
            qb.where(BaseActivitySummaryDao.Properties.DeviceId.eq(dbDevice.getId())).orderDesc(BaseActivitySummaryDao.Properties.StartTime);
            List<BaseActivitySummary> allSummaries = qb.build().list();
            setItems(allSummaries, true);
        } catch (Exception e) {
            GB.toast("Error loading activity summaries.", Toast.LENGTH_SHORT, GB.ERROR, e);
        }
    }

    @Override
    protected String getName(BaseActivitySummary item) {
        String name = item.getName();
        if (name != null && name.length() > 0) {
            return name;
        }

        Date startTime = item.getStartTime();
        if (startTime != null) {
            return DateTimeUtils.formatDateTime(startTime);
        }
        return "Unknown activity";
    }

    @Override
    protected String getDetails(BaseActivitySummary item) {
        return ActivityKind.asString(item.getActivityKind(), getContext());
    }

    @Override
    protected int getIcon(BaseActivitySummary item) {
        return ActivityKind.getIconId(item.getActivityKind());
    }
}
