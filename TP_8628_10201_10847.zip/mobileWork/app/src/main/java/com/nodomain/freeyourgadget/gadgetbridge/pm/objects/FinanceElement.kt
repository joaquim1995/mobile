package objects

data class FinanceElement (val name: String = "", val age: String = "", var uuid: String = "")